#include <iostream>
using namespace std;
int fact(int n){
    int factorial=1;
    for(int i=1;i<=n;i++){
        factorial*=i;
    }
    return factorial;
}
int main()
{
    int n,r;
    cin>>n>>r;
    int a=fact(n);
    int b=fact(n-r);
    int c=fact(r);
    int ans=a/(b*c);
    cout<<ans;
    return 0;
}